Dates.java:9: error: illegal start of expression
        if (month == 9) || (month == 4) || (month == 6) || (month == 11)) {
                        ^
Dates.java:33: error: ';' expected
    for (aMonth = 0, aMonth < someMonth; aMonth = aMonth + 1) {
Dates.java:1: error: class, interface, or enum expected
nano Dates.javaimport java.io.*;     

1. Java Debugger its so you can step through each line and put breakpoints to determine what the problem is.
2. will tell the complier to peovide info on that jdb can use to display stacks
3. a) stop in sets a breakpoint in a method so stop in Dates.main sets a breakpoint in main
   b) stop at sets a brakpoint at a certain line so stop at Dates:2 sets breakpoint at line 2
   c) run will run the program in the debugger so run Dates will run dates
   d) cont is contine excution from breakpoint so if theres a break point the program will stop but cont will make continue till next breakpoint
   e) list prints souce code so list[31|main] will list the code at line 31 in main
   f) locals prints all local variables in current stack frame so locals could print daysinbetween or some other
   g) print prints value of expression so print<expr> could print the value of amonth
