package cs1302.arcade;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer; //Java Swing was used rather than JavaFX  

public class TetrisBoard extends JPanel implements KeyListener{
	
	private BufferedImage tiles;	
	
	private final int blockSize = 30;
	
	private final int WIDTH = 10;
 
	private final int 	HEIGHT = 20;
	
	private int[][] board = new int[HEIGHT][WIDTH];
	
	private Shape[] tileShapes = new Shape[7];
	
	private Shape currentShape;
	
	private Timer looper;
	
	private final int FPS = 60; 
	
	private final int delay = 1000/FPS;
	
	public  boolean gameOver = false;
	
	public int score;
	
	public TetrisBoard(){
		
		try {//calling resource tile.png to represent the block colors
			tiles = ImageIO.read(TetrisBoard.class.getResource("/tiles.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		looper = new Timer(delay, new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				update();// calls from update on tetrisboard
				repaint();
			}
		});
		
		looper.start();
		
		// shapes
		
		tileShapes[0] = new Shape(tiles.getSubimage(0, 0, blockSize, blockSize), new int[][]{
			{1,	 1,		 1, 	1} // IShape /**
      /**
       numbers representing space or no space
       1 equals to a space 0 equals to no space so the corresponding 2array will be a shape 
      */
		}, this, 1);
		
		tileShapes[1] = new Shape(tiles.getSubimage(blockSize, 0, blockSize, blockSize), new int[][]{
			{1, 	1, 		0},
			{0, 	1, 		1}   // ZShape
		}, this, 2);
		
		tileShapes[2] = new Shape(tiles.getSubimage(blockSize*2, 0, blockSize, blockSize), new int[][]{
			{0, 	1, 		1},
			{1, 	1, 		0}   // S-Shape
		}, this, 3);
		
		tileShapes[3] = new Shape(tiles.getSubimage(blockSize*3, 0, blockSize, blockSize), new int[][]{
			{1, 	1, 		1},
			{0, 	0, 		1}   // J-Shape
		}, this, 4);
		
		tileShapes[4] = new Shape(tiles.getSubimage(blockSize*4, 0, blockSize, blockSize), new int[][]{
			{1,	 1, 	1},
			{1,	 0, 	0}   // L-Shape
		}, this, 5);
		
		tileShapes[5] = new Shape(tiles.getSubimage(blockSize*5, 0, blockSize, blockSize), new int[][]{
			{1, 	1, 		1},
			{0,	 1, 	0}   // T-Shape
		}, this, 6);
		
		tileShapes[6] = new Shape(tiles.getSubimage(blockSize*6, 0, blockSize, blockSize), new int[][]{
			{1, 1},
			{1, 1}   // O-Shape
		}, this, 7);
		
		currentShape();
		
	}
	
	public void update(){//references current object from shape and calls update from there
// also if gameover called then loop stops 
		currentShape.update();
		if(gameOver)
			looper.stop();
	}
	
	
	public void paint(Graphics graphics){ //paintComponent does not have an equal to 
 // in Javafx only canvas seems close 
		int row = 0;
		
		while(row < board.length){
			
			
			for(int column = 0; column < board[row].length; column++){
				
				
				if(board[row][column] != 0)
					graphics.drawImage(tiles.getSubimage((board[row][column]-1)*blockSize, 0, blockSize, blockSize),
					column*blockSize, row*blockSize, null);
			}
			row++;
		}
		
		int i=0;
		while( i < HEIGHT){
			graphics.drawLine(0, i*blockSize, WIDTH*blockSize, i*blockSize);
			i++;
		}
		int j = 0;
		while( j < WIDTH){
			graphics.drawLine(j*blockSize, 0, j*blockSize, HEIGHT*blockSize);
			j++;
		}
		
		if(gameOver)
		{
			String gameOverString = "GAME OVER";
			graphics.setColor(Color.BLACK);
			graphics.setFont(new Font("Verdana", Font.BOLD, 30));
			graphics.drawString(gameOverString, 50, Window2.HEIGHT/2);
		}	
			graphics.setColor(Color.BLACK);
		
		graphics.setFont(new Font("Verdana", Font.BOLD, 20));
		
		graphics.drawString("SCORE", Window2.WIDTH - 90, Window2.HEIGHT-600);
		graphics.drawString(score+"", Window2.WIDTH - 90, Window2.HEIGHT- 570);
		
		
	}
	
	public void currentShape(){
		
		int index = (int)(Math.random()*tileShapes.length);
		
		Shape newShape = new Shape(tileShapes[index].getBlock(), tileShapes[index].getCoords(),
				this, tileShapes[index].getColor());
		
		currentShape = newShape;
		
	int row = 0;
		do{
			for(int col = 0; col < currentShape.getCoords()[row].length; col++){
				
			
				if(currentShape.getCoords()[row][col] != 0){
					
					if(board[row][col + 3] != 0)
						gameOver = true;
				}
	
			}
			row++;
		}while(row < currentShape.getCoords().length);
	
		
		
	}
	public void startGame(){//start game calls current shape 
 //re states game over is false and start loop again
		stopGame();
		currentShape();
		
		gameOver = false;
		looper.start();
		
	}
	public void changeDifficulty(){
		
	}
	public void stopGame(){
 // return score to 0 
 //if row is higher than board length which is the height of frame then game over
		score = 0;
		int row = 0;
		
		while(row < board.length)
		{
			for(int col = 0; col < board[row].length; col ++)
			{
				board[row][col] = 0;
			}
			row++;
		}
		looper.stop();
	}
	
	


	public int getBlockSize(){
		return blockSize;
	}

	public int[][] getBoard(){
		return board;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_LEFT)//intuitive arrow keys
			currentShape.setDeltaX(-1);
		if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			currentShape.setDeltaX(1);
		if(e.getKeyCode() == KeyEvent.VK_DOWN)//pressing down refrences speed down so faster
			currentShape.speedDown();
		if(e.getKeyCode() == KeyEvent.VK_UP)
			currentShape.rotate();
	}

	@Override
	public void keyReleased(KeyEvent e) {//releasing the key returns to same speed as normal
		if(e.getKeyCode() == KeyEvent.VK_DOWN)
			currentShape.normalSpeed();
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	public void addScore(){
		score ++; //adds score 1 point per block until game over
	}
}
