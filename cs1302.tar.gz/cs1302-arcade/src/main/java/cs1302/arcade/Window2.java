package cs1302.arcade; 

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Window2 implements ActionListener { 
	
	public static final int WIDTH = 307, HEIGHT = 630;
	private JFrame frame;
	private TetrisBoard board;
	
	public Window2(){
		
		frame = new JFrame("Tetris Game");
		frame.setSize(WIDTH, HEIGHT);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		
		JMenuBar menuBar = new JMenuBar();
		
		JMenu menu = new JMenu("Options");
		
		 JMenuItem newGame = new JMenuItem("New Game");
		    newGame.addActionListener(new ActionListener(){
		    	public void actionPerformed(ActionEvent e){
		    			board.startGame();
		    		
		    		
		    	}
		    });
		     
		    JMenuItem quitGame = new JMenuItem("Quit Game");
		    quitGame.addActionListener(new ActionListener(){
		    	public void actionPerformed(ActionEvent e){
		    		System.exit(0);
		    		
		    	}
		    });
		    JMenuItem switchGame = new JMenuItem("Switch Game");
		    quitGame.addActionListener(new ActionListener(){
		    	public void actionPerformed(ActionEvent e){
		    		
		    		
		    	}
		    });
		    JMenuItem difficulty = new JMenuItem("Change Difficulty");
		    quitGame.addActionListener(new ActionListener(){
		    	public void actionPerformed(ActionEvent e){
		    		
		    		
		    	}
		    });
		    menu.add(newGame);
		    menu.add(switchGame);
		    menu.add(quitGame);
		menuBar.add(menu);
		board = new TetrisBoard();
		frame.setJMenuBar(menuBar);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setPreferredSize(new Dimension(307, 658));
	    frame.pack();
	    frame.setLocationRelativeTo(null);
	    frame.setVisible(true);
		
		
		
		frame.add(board);
		frame.addKeyListener(board);
		
		
		frame.setVisible(true);
	}
	
	
	
    /**    	public static void main(String[] args) {
		new Window2();
		}*/
    public static void start() {
	new Window2();
    }
    


	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
