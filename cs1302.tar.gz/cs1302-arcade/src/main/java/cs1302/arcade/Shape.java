package cs1302.arcade;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Shape {
	
	private BufferedImage tile;
 
	private int[][] cords;
 
	private TetrisBoard board;
 
	private int deltaX = 0;
 
	private int x, y;
	
	private int color;
	
	private boolean collision = false, moveX = false;
	
	private int normalSpeed = 600, speedDown = 60, currentSpeed;
	
	
	private long time, lastTime;
	
	public Shape(BufferedImage tile, int[][] cords, TetrisBoard board, int color){
		this.tile = tile; // referecning new onject board from TextrisBoard
		this.cords = cords;
		this.board = board;
		this.color = color;
		
		currentSpeed = normalSpeed;//current speed is the generic for speedDown and normalSpeed
		time = 0;
		lastTime = System.currentTimeMillis();
		
		x = 3;
		y = 0;
		
	}
	
	public void update(){
		time += System.currentTimeMillis() - lastTime;
		lastTime = System.currentTimeMillis();
		
		if(collision)
		{
			int row = 0;
			while(row < cords.length){
				for(int column = 0; column < cords[row].length; column++){
					if(cords[row][column] != 0){
						board.getBoard()[y + row][x + column] = color;
					}
				}
				row++;
			}
			checkLine();
			board.addScore();//adds score per collision had issues with collision

			board.currentShape();
		}

		
		if(!(x + deltaX + cords[0].length > 10) && !(x + deltaX < 0))
		{
			int row = 0;
			do {
				for(int col = 0; col < cords[row].length; col++){
					if(cords[row][col] != 0)
					{
						if(board.getBoard()[y + row][x + deltaX + col] != 0)
							moveX = false;
					}
				}
				row++;
			}
			while(row < cords.length);
			
			
			if(moveX)
				x += deltaX;
		}		
			
		
		if(!(y + 1 + cords.length > 20))
		{
			int row = 0;
			do {
			
				for(int col = 0; col < cords[row].length; col++)
				{
					if(cords[row][col] != 0)
					{
						if(board.getBoard()[y + row + 1][col + x] != 0)
							collision = true;
					}
				}
				row++;
			
			}while(row < cords.length);
			if(time > currentSpeed)
				
			{
				y++;
				time = 0;
			}
		}else{
			collision = true;
		}
		
		deltaX = 0;
		moveX = true;
	}
	
	
	
	
	
	
	
	public void render(Graphics g){
		int row = 0;
		do{
			
		
			for(int col = 0 ; col < cords[row].length; col++)
				if(cords[row][col] != 0)
					g.drawImage(tile, col*board.getBlockSize() + x*board.getBlockSize(),
							row*board.getBlockSize() + y*board.getBlockSize(), null);
		
		row++;
	}
		while(row < cords.length);
	}
	private void checkLine(){
		int height = board.getBoard().length - 1;
		int i = height;
		while( i > 0){
			
			int count = 0;
			for(int j = 0; j < board.getBoard()[0].length; j++){
				
				if(board.getBoard()[i][j] != 0)
					count ++;
				
				board.getBoard()[height][j] = board.getBoard()[i][j];
				
			}
			if(count < board.getBoard()[0].length){
				height --;
			}
			i--;
		}
		
		
	}
	
	
	public void rotate(){
		
		if(collision)
			return;
		
		int[][] rotator = null;
		
		rotator = getTranspose(cords);
		
		rotator = getReverseMatrix(rotator);
		
		if(x + rotator[0].length > 10 || y + rotator.length > 20)
			return;
		
		int row = 0;
		do{
			for(int col = 0; col < rotator[0].length; col++){
				
				if(board.getBoard()[y + row][x + col] != 0){
					return;
				}
				
			}
			row++;
		}while(row < rotator.length);
		
		cords = rotator;
		
	}
	
	private int[][] getTranspose(int[][] matrix){
		int[][] newMatrix = new int[matrix[0].length][matrix.length];
		int i = 0;
		do{
			for(int j = 0; j < matrix[0].length; j++){
				newMatrix[j][i] = matrix[i][j];
				
			}
			i++;
		}while( i < matrix.length);
		return newMatrix;
		
		
	}
	
	private int[][] getReverseMatrix(int[][] matrix){
		int middle = matrix.length / 2;
	int	i = 0;
		do {
			int[] m = matrix[i];
			matrix[i] = matrix[matrix.length - i - 1];
			matrix[matrix.length - i - 1] = m;
			i++;
		}while(i < middle);
		return matrix;
	}
	
	
	
	
	public void setDeltaX(int deltaX){
		this.deltaX = deltaX;
	}
	
	public void normalSpeed(){
		
		currentSpeed = normalSpeed;
	}
	
	
	
	public void speedDown(){
		currentSpeed = speedDown;
	}

	public BufferedImage getBlock() {//getters
		return tile;
	}

	public int[][] getCoords() {
		return cords;
	}
	public int getColor(){
		return color;
	}
	
}
