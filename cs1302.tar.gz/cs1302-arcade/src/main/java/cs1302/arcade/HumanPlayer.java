package cs1302.arcade;
//package cs1302-reversi.cs1302.p2;
import java.util.Scanner;

/**
 * Human Player class will give human player all methods needed to take input and play game.
 */

public class HumanPlayer extends Player {
    private int row;
    private int col;
    private String color;
   
    /**
     * Returns the row of class HumanPlayer
     * @return row Is row associated to private in row int HumanPlayer class
     */
    public int getRow(){
	return row;
    }
    /**
     * Returns the col of class HumanPlayer
     * @return col Is col associated to privat int col in HumanPlayer class
     */
    public int getCol(){
	return col;
    }
    /**
     * Gathes user input from Human and sets this.row and this.col equal to it for use with Player.usePiece().
     * @param team Is team of player making move.
     */
    public void setRowCol(int team){
	Scanner keyboard = new Scanner(System.in);
	if(team == 1){                                              
            color = "X";                                                       
        }                                                              
        else{                                                          
            color = "0";                                                
	}                                               
    	
	System.out.println("Enter your move " + color +" player: ");
	int row = keyboard.nextInt() - 1;
	int col = keyboard.nextInt() - 1;
	this.row = row;
	this.col = col;
    }
    /*    public void color(){
	if(team == 1){
	    color = "X";
	}
	else{
	    color = "0";
    }

    }*/
}