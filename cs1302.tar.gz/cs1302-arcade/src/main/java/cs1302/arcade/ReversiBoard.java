
package cs1302.arcade;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Dialog;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import java.util.Scanner;
import javafx.application.Application;
import javafx.scene.layout.Pane;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
//package cs1302-reversi.cs1302.p2;
/**
 * Reversi Board is a child of parent class Board and gives us all the tools we need to mod reversi game board.
 */






public class ReversiBoard extends Board {
    private int allSpace;
    private int wSpace;
    private int bSpace;

    /**
     * Gets total value of possible movements on board.
     * @return tot equal to total number of availble places to currently place piece.
     */
   



    /**
    public int getAll(){
	int tot=0;
	for(int i = 0; i < 8; i++){
            for(int v = 0; v < 8; v++){
                if(board[i][v] == 3){
                    tot++;
		}
	    }
	}
	//allSpace = board.getxCount() + board.get0Count();
	return tot;
    }

    /**
     * places token on board.
     * @param row Is the row of desiered piece
     * @param col Is the col of desired piece
     * @param team Is the team of desired pieece to place..
     */
   




 public void placeToken(int row, int col, int team){
	if(board[row][col] == 0){
	    board[row][col] = team;
	}

    }
   
    /**
     * Checks to see if someone has won the game yet.
     * @return Boolean value is returned whether game is won or not.
     */
    public boolean win(){
	int counter = 0;
	int posCounter = 0;
	for(int i = 0; i < 8; i++){
	    for(int v = 0; v < 8; v++){
		if(board[i][v] == 1 || board[i][v] == 2){
		    counter++;
		}
		else if(board[i][v] == 3){
		    posCounter++;
		}
	    }
	}
	if(counter == 64){
	    return false;
		}
	else if(posCounter == 0){
	    return false;
		}
	
	    return true;
	
    }//win
    /**
     * Calculates total possible places a token can be placed for specified team and updates board accordinly.
     * @param team Is a value that passed to determine what player to calculate possible moves for.
     */

    public void possiblePlace(int team){
	int add;
	int otherTeam;
	if(team == 1){otherTeam = 2;}
	else{otherTeam = 1;}
	for(int i = 0; i < 8; i++){
	    for(int v = 0; v < 8; v++){
		if(board[i][v] == team){
		    add = 0;
		    for(int r = 1; v+r < 8; r++){
			if(board[i][v+r] == 0 && add > 0){
			    board[i][v+r] = 3;
			    add = 0;
			    break;
			}
			else if(board[i][v+r] == 0){
			    break;
			}
			else if(board[i][v+r] == team){
			    break;}
			else if(board[i][v+r] == otherTeam){
			    add++;
			}
		    }
		}
	    }
	}//for-loop for right moving horizontal
	for(int i = 7; i >= 0; i--){
            for(int v = 7; v >= 0; v--){
		if(board[i][v] == team){
                    add = 0;
		    for(int r = 1; v-r >= 0; r++){
			if(board[i][v-r] == 0 && add > 0){
                            board[i][v-r] = 3;
                            add = 0;
			    break;
                        }
			else if(board[i][v-r] == 0){
			    break;
			}
			else if(board[i][v-r] == team){
                            break;}
                        else if(board[i][v-r] == otherTeam){
                            add++;
                        }
                    }
                }
	    }
	}//for-loop for left moving horizontal
	for(int i = 7; i >= 0; i--){
            for(int v = 7; v >= 0; v--){
                if(board[i][v] == team){
                    add = 0;
                    for(int r = 1; i-r >= 0; r++){
                        if(board[i-r][v] == 0 && add > 0){
                            board[i-r][v] = 3;
                            add = 0;
			    break;
                        }
			else if(board[i-r][v] == 0){
			    break;
			}
                        else if(board[i-r][v] == team){
                            break;}
                        else if(board[i-r][v] == otherTeam){
                            add++;
                        }
                    }
                }
	    }
	}//for-loop for upward vertical
		for(int i = 0; i < 8; i++){
		    for(int v = 0; v < 8; v++){
			if(board[i][v] == team){
			    add = 0;
			    for(int r = 1; i+r < 8; r++){
				if(board[i+r][v] == 0 && add > 0){
				    board[i+r][v] = 3;
				    add = 0;
				    break;
				}
				else if(board[i+r][v] == 0){
				    break;
				}
				else if(board[i+r][v] == team){
				    break;}
				else if(board[i+r][v] == otherTeam){
				    add++;
				}
			    }
			}
		    }
		}//for-loop for downward vertical
		for(int i = 0; i < 8; i++){
		    for(int v = 0; v < 8; v++){
			if(board[i][v] == team){
			    add = 0;
			    for(int r = 1; v+r < 8 && i+r < 8; r++){
				if(board[i+r][v+r] == 0 && add > 0){
				    board[i+r][v+r] = 3;
				    break;
				}
				else if(board[i+r][v+r] == 0 || board[i+r][v+r] == 3 ){
                                    break;
				}
				else if(board[i+r][v+r] == otherTeam){
				    add++;
				}
			    }
			}
		    }
		}//for-loop for diagnol downward left to right
		for(int i = 0; i < 8; i++){
                    for(int v = 0; v < 8; v++){
                        if(board[i][v] == team){
                            add = 0;
                            for(int r = 1; v-r >= 0 && i+r < 8; r++){
                                if(board[i+r][v-r] == 0 && add > 0){
                                    board[i+r][v-r] = 3;
				    break;
				}
				else if(board[i+r][v-r] == 0 || board[i+r][v-r] == 3){
                                    break;
				}
                                else if(board[i+r][v-r] == otherTeam){
                                    add++;
                                }
                            }
                        }
                    }
                }//for-loop for diagnol downward right to left
		for(int i = 0; i < 8; i++){
                    for(int v = 0; v < 8; v++){
                        if(board[i][v] == team){
                            add = 0;
                            for(int r = 1; i-r >= 0 && v+r < 8; r++){
                                if(board[i-r][v+r] == 0 && add > 0){
                                    board[i-r][v+r] = 3;
				    break;
                                }
				else if(board[i-r][v+r] == 0 || board[i-r][v+r] == 3){
                                    break;
				}
                                else if(board[i-r][v+r] == otherTeam){
                                    add++;
                                }
                            }
                        }
                    }
                }//for-loop for diagnol upward left to right
		for(int i = 0; i < 8; i++){
                    for(int v = 0; v < 8; v++){
                        if(board[i][v] == team){
                            add = 0;
                            for(int r = 1; v-r >= 0 && i-r >= 0; r++){
                                if(board[i-r][v-r] == 0 && add > 0){
                                    board[i-r][v-r] = 3;
				    break;
				}
				else if(board[i-r][v-r] == 0|| board[i-r][v-r] == 3){
                                    break;
				}
                                else if(board[i-r][v-r] == otherTeam){
                                    add++;
                                }
                            }
                        }
                    }
                }//for-loop for diagnol upward right to left
    }//possible
    /**
     *clears board of possible places to play.
     */
    public void clearPossible(){
	for(int i = 0; i < 8; i++){
            for(int v = 0; v < 8; v++){
		if(board[i][v] == 3){
		    board[i][v] = 0;
		}
	    }
	}
    }

    /**
     * flip takes in row col and team and flips all the correct pieces surrounding based off rules.
     *@param row Is row the piece placed is located on.
     *@param col Is col the piece placed is located on.
     *@param team Is team the piece placed is on.
     */ 
    public void flip(int row, int col, int team){
	int add;
	int otherTeam;
	int i = row;
        int v = col;
        if(team == 1){otherTeam = 2;}
        else{otherTeam = 1;}
	//for(int i = row; i < 8; i++){
	//  for(int v = col; v < 8; v++){
                    add = 0;
                    for(int r = 1; v+r < 8; r++){
                        if(board[i][v+r] == otherTeam){
			    add++;
			    
			}    
			else if(board[i][v+r] == team){
			    for(int b = add; b > 0; b--){
			    board[i][v+r-b] = team;
			    }
			}
		    }
		    //  }
		    //	}//for-loop for the right side flips

		add = 0;
		for(int r = 1; v-r >=0; r++){
		    if(board[i][v-r] == otherTeam){
			add++;
		    }
		    else if(board[i][v-r] == team){
			for(int b = add; b>0; b--){
			    board[i][v-r+b]=team;
			}
		    }
		}//for-loop for the left side flips


		//for(int i = row; i < 8; i++){
		//for(int v = col; v < 8; v++){
		add = 0;
		for(int r = 1; i+r < 8; r++){
		    if(board[i+r][v] == otherTeam){
			add++;
		    }
		    else if(board[i+r][v] == team){
			for(int b = add; b > 0; b--){
                            board[i+r-b][v] = team;
			}
		    }
		}
		// }
		//        }//for-loop for the vertical down flips
		//for(int i = row; i >= 0; i--){
		//for(int v = col; v >= 0; v--){
                add = 0;
                for(int r = 1; i-r >=0; r++){
                    if(board[i-r][v] == otherTeam){
                        add++;
                    }
                    else if(board[i-r][v] == team){
                        for(int b = add; b>0; b--){
                            board[i-r+b][v]=team;
                        }
                    }
                }
		//      }
    //}//for-loop for the vertical up flips
		//	for(int i = row; i >=0; i--){
		//	    for(int v = col; v >= 0; v--){
		    add = 0;
		    for(int r = 1; v-r >= 0 && i-r >= 0; r++){
			if(board[i-r][v-r] == otherTeam){
			    add++;
			}
			else if(board[i-r][v-r] == team){
			    for(int b = add; b>0; b--){
				board[i-r+b][v-r+b]=team;
			}
		    }
		}
		    //	    }
    //	}//for-loop for diagnol upward right to left flips
		    //	for(int i = row; i < 8; i++){
	    //	    for(int v = col; v < 8; v++){
		add = 0;
		for(int r = 1; v+r < 8 && i+r < 8; r++){
		    if(board[i+r][v+r] == otherTeam){
			add++;
		    }
		    else if(board[i+r][v+r] == team){
			for(int b = add; b>0; b--){
			    board[i+r-b][v+r-b]=team;
                        }
                    }
                }
		//      }
    //        }//for-loop for diagnol downward left to right flips
		//	for(int i = row; i < 8; i++){
		//	    for(int v = col; v >= 0; v--){
		add = 0;
		for(int r = 1; v-r >= 0 && i+r < 8; r++){
			if(board[i+r][v-r] == otherTeam){
			    add++;
			}
			else if(board[i+r][v-r] == team){
			    for(int b = add; b>0; b--){
				board[i+r-b][v-r+b]=team;
			    }
			}
		}
		//	    }
		//	}//for-loop for diagnol downward right to left
		//	for(int i = row; i >= 0; i--){
		//            for(int v = col; v < 8; v++){
                add = 0;
                for(int r = 1; v+r < 8 && i-r >= 0; r++){
		    if(board[i-r][v+r] == otherTeam){
			add++;
		    }
		    else if(board[i-r][v+r] == team){
			for(int b = add; b>0; b--){
			    board[i-r+b][v+r-b]=team;
			}
		    }
                }
		//            }
		//        }
    }//flip
    public void start(Stage primarySTage) throws Exception {

    }


}//Reversi



