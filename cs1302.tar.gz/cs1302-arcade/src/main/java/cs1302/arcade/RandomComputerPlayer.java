package cs1302.arcade;
//package cs1302-reversi.cs1302.p2;
import java.lang.Math;
/**
 *Gives Computer player all methods needed to play game.
 */

public class RandomComputerPlayer extends ComputerPlayer {
    private int row;
    private int col;
    private String color;

    /**
     * Finds a random value based off availble options for placement.
     * @param randy Is a int value representing the amount of possible placements for team to make on turn.
     * @param team Is the team associated with player making move.
     */

    public void getRandPlay(int randy, int team){
	if(team == 1){
            color = "X";
	}
        else{
            color = "0";
        }
	System.out.println("Enter you move, "+color+"  player: ");
	try {
	    Thread.sleep(4000);
	} catch (InterruptedException ie) {
	    //Handle exception
	}
	int add = 0;
	int ranDig;
	ranDig =(int)(randy * Math.random());
	for(int i = 0; i < 8; i++){
            for(int v = 0; v < 8; v++){
		if(Board.board[i][v] == 3){
		    if(add == ranDig){
			row = i;
			col = v;
			 }
		    add++;
		}
	    }
	}
    }//getRandPlay
    
    /**
     * Gets row value associated with private int row in RandomComputerPlayer class.
     * @return private int row is returned
     */
    public int getRow(){
	return row;
    }
    /**
     * Gets col value associated with private int col in RandomComputerPlayer class.
     * @return private int col is returned
     */
    public int getCol(){
	return col;
    }
}//RandomComputerPlayer