# Reflection

12/12/2017

I pushed on every push day, but found out that it wasnt pushing last week. 
As you can see our original push was way back when, and then once we realized
we pushed again today. 

Challenges: The biggest challenges came with trying to use old reversi code.
I got a good grade on my reversi and decided to try and code it again, it
was a huge headache trying to use old code as a skeleton. I got too deep in
and was stuck trudging through old code and probably shouldve done the whole
thing from scratch in the beginning. 

Looking Back: We definitely should've realized our GitHub wasnt being pushed to.
As soon as I realized how powerful github was I was really bummed out we hadnt
been checking it as much. Also, because we weren't using github as much, we 
coded on two different platforms. My method was to stay in emacs and try and
push to github, while my partner stayed in eclipse. IT didnt work well in the 
end becuase he coded his tetris outside of javafx and the compatabillity ended
up being the hardest issue. 