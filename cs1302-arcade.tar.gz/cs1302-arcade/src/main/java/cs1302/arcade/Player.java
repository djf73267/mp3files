package cs1302.arcade;
//package cs1302-reversi.cs1302.p2;
/**
 * Player class allows us to share the methods needed amongst our subclasses.
 */
    public abstract class Player {
	private String name;
	private boolean turns;
	private int counter = 1;

	/**
	 * Uses piece desired by user and checks validitiy and changes board.
	 * @param row Is row of desired piece to check and change
	 * @param col Is col of desired piece to check and change
	 * @param team Is team of desired piece to check and change
	 */
	public void usePiece(int row, int col, int team){
	    if(Board.board[row][col] == 3){
		Board.board[row][col] = team;
	    }
	    else{ System.out.print("Can't Make that Move");}
	}
	/*	public int getTeam(){
	    return team;
	    }*/
    }       













