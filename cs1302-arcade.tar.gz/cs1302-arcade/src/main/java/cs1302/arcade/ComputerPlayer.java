package cs1302.arcade;
//package cs1302-reversi.cs1302.p2;
public abstract class ComputerPlayer extends Player {
    







}