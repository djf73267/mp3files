
package cs1302.arcade;
import java.util.Random;
import javax.swing.SwingUtilities;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Dialog;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import java.util.Scanner;
import javafx.scene.Node;
import javafx.geometry.Pos;
/**
 *@author Grant godbee
 *Runs the arcade app opening menu page and launches into games when button is pressed.
 */
public class ArcadeApp extends Application {
    HBox hbox = new HBox();
 
    Button reversi = new Button("Reversi");
    Button tetris = new Button("Tetris");
    Rectangle r = new Rectangle(20, 20); // some rectangle                                                                                             

    Random rng = new Random();
    BorderPane BordPane = new BorderPane();

    Scene scene = new Scene(BordPane);
    @Override
	
    public void start(Stage stage) {
	r.setX(50);                          // 50px in the x direction (right)
	r.setY(50);                          // 50ps in the y direction (down)
	/**reversi.relocate(212,240);
	   tetris.relocate(424, 240);*/
	hbox.getChildren().addAll(reversi, tetris);
	BordPane.setCenter(hbox);          // add to main container
	hbox.setAlignment(Pos.CENTER);

	final Menu topMenu = new Menu("File");
        final Menu helpMenu = new Menu("Help");
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(topMenu, helpMenu);
        MenuItem exitItem = new MenuItem("Exit");
	MenuItem aboutItem = new MenuItem("About Grant Godbee");
	//      ToolBar toolBar = new ToolBar();                                                                                                                 
	aboutItem.setOnAction(e->{
		Alert alert = new Alert(AlertType.WARNING);
		alert.setTitle("About Creators");
		alert.setHeaderText("Grant Godbee email:");
		alert.setContentText("Version 1.0.0");

		alert.showAndWait();
	    });
        exitItem.setOnAction(e->{                Platform.exit();
                System.exit(0);
            });

	topMenu.getItems().add(exitItem);
        helpMenu.getItems().add(aboutItem);

	
	// when the user clicks on the rectangle, send to random position
	reversi.setOnAction(e -> {
      	System.out.println("Launching Reversi");	       
	App app = new App();
	BordPane.getScene().setRoot(app.getRoot());
	
	    });
	tetris.setOnAction(e ->{
		System.out.println("Launching Tetris");
	
		Window2.start();
	    });
    
	BordPane.setPrefHeight(640);
	BordPane.setPrefWidth(480);

	reversi.relocate(212,240);
        tetris.relocate(424, 240);

        BordPane.setTop(menuBar);
             
        stage.setTitle("cs1302-arcade!");
        stage.setScene(scene);
	stage.sizeToScene();
	stage.show();
    }//start
    public static void main(String[] args) {
	try {
	    Application.launch(args);
	} catch (UnsupportedOperationException e) {
	    System.out.println(e);
	    System.err.println("If this is a DISPLAY problem, then your X server connection");
	    System.err.println("has likely timed out. This can generally be fixed by logging");
	    System.err.println("out and logging back in.");
	    System.exit(1);
	} // try
    } // main

} // ArcadeApp

