
package cs1302.arcade;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Dialog;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import java.util.Scanner;
import javafx.application.Application;
import javafx.scene.layout.Pane;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.shape.*;
import javafx.scene.paint.Color;
import javafx.geometry.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.scene.layout.VBox;

public abstract class Board extends Application {
    private int row;
    private int col;
    Label winner;
    VBox gO= new VBox();
    BorderPane gameOv = new BorderPane();
    GridPane upd;
    HBox hbox;
    int temp;
    Label label = new Label("E");
    Label labelB = new Label("B");
    Label labelW = new Label("W");
    Label labelP = new Label("-");
    Circle[] blackChips = new Circle[128];
    Circle[] whiteChips = new Circle[128];
    Circle[] possibleChip = new Circle[128];
    Circle[] emptyChip = new Circle[128];
    BorderPane gP2 = new BorderPane();
    int gameVar = 0;
    protected static int[][] board = new int [8][8];
    Button backToHome = new Button("Return to Arcade");
    Button tetris = new Button("Tetris");
    Button reversi = new Button("Reversi");
    /** 
    *public int Board constructor
     * @return a double array of initialized board
     */
    
    public int[][] Board(){
	gameVar = App.gameV();
	for(int i = 0; i < 8; i++){
	    for(int v = 0; v < 8; v++){
		board[i][v]=0;
	    }
	}
	board[3][3] = 1;
	board[4][4] = 1;
	board[3][4] = 2;
	board[4][3] = 2;
	upd = new GridPane();
	upd.setPrefWidth(480);
	upd.setPrefHeight(480);
	upd.setAlignment(Pos.CENTER);
	return board;
    }//Board constructor
    /**
     * Prints the array board.
     */
    /**
     *public void placeToken
     */
    public void placeToken(int row, int col, int team){
	// if(board[row][col] == 3){
	board[row][col] = team;
	// }
	
    }
    /**                                                                                                                                                   
     *public BorderPane printBoard runs the game as users click through                                                                                       *@return a borderpane that is used within App class
     */
    public BorderPane printBoard(int team){

	backToHome.setOnAction(e -> {                                                                                                                   
		gO.getChildren().clear();
		gO.getChildren().addAll(tetris, reversi);
		gO.setAlignment(Pos.CENTER);
		gameOv.setCenter(gO);
		gP2.setCenter(gameOv);
            });

	possiblePlace(1);
	possiblePlace(2);
	if(win() == false){
	    Label gameOver = new Label("Game Over");
	    if(getxCount() > get0Count()){
		winner = new Label("The black chips win!");
	    }
	    else if(getxCount() < get0Count()){                                                                                                                            

		winner = new Label("The White chips win!");
	    }
	    else{
		winner = new Label("It is a tie!");
	    }
	    gO.getChildren().addAll(gameOver, winner);
	    gO.setAlignment(Pos.CENTER);
	    gameOv.setCenter(gO);
	    gP2.setCenter(gameOv);
	    return gameOv;
	}//if for p1 player and p2 comp     
	
	clearPossible();
	possiblePlace(1);
        gP2.setCenter(upd);
        upd.setPrefWidth(480);
        upd.setPrefHeight(480);

	System.out.print("\n    1 2 3 4 5 6 7 8\n  ");
	for(int u = 0; u < 8; u++){
	    System.out.print( u + 1);
	    for(int m = 0; m < 8; m++){
		final int i = u;
		final int v = m;
		final int w = 1;
		if(board[i][v] == 0){    
		    emptyChip[i+(v*8)] = new Circle(20,Color.GREEN);
		    upd.add(emptyChip[i+(v*8)], v, i);
		    
		    System.out.print(" .");
		}
		else if(board[i][v] == 1){
		    blackChips[i+(8*v)] = new Circle(20, Color.BLACK);
		    upd.add(blackChips[i+(8*v)], v, i);
		    System.out.print(" X");
		}
		else if(board[i][v] == 2){
		    whiteChips[i+(8*v)] = new Circle(20, Color.WHITE);
		    upd.add(whiteChips[i+(8*v)], v, i);
		    System.out.print(" 0");
		}
		else if(board[i][v] == 3){
		    possibleChip[i+(8*v)] = new Circle(20, Color.RED);
		    upd.add(possibleChip[i+(8*v)], v, i);
		    temp = i*v;
		    possibleChip[i+(8*v)].setOnMouseClicked(event -> {
			    
			    if(getAll() > 0){
				board[upd.getRowIndex(possibleChip[i+(8*v)])][upd.getColumnIndex(possibleChip[i+(8*v)])] = 1;
				flip((upd.getRowIndex(possibleChip[i+(8*v)])) , (upd.getColumnIndex(possibleChip[i+(8*v)])), 1);                                               
				clearPossible();
				if(gameVar == 2){printBoard2(2);}
				else if(gameVar == 1){
				    printBoardRand2(2);
				}
			                                                                                                                                                      
			    }else{
				if(gameVar == 2){printBoard2(2);}
                                else if(gameVar == 1){
                                    printBoardRand2(2);
				}
			    }        
			                                                                                                                                                      
			});
		    System.out.print(" _");
		}
	    }// everything else
	    System.out.print("\n");
	}
		return gP2;
    }//printBoard 
    
    
    /**                                                                                                                                                   
     *public BorderPane printBoard2 is similar to printboard but allows user to play with a friend
     *@return BorderPane is returned that shows possible places for player 2
     */
     public BorderPane printBoard2(int team){
	backToHome.setOnAction(e -> {
                gO.getChildren().clear();
                gO.getChildren().addAll(tetris, reversi);
                gO.setAlignment(Pos.CENTER);
                gameOv.setCenter(gO);
                gP2.setCenter(gameOv);
            });

	possiblePlace(1);
        possiblePlace(2);
        if(win() == false){
            Label gameOver = new Label("Game Over");
            if(getxCount() > get0Count()){
                winner = new Label("The black chips win!");
            }
            else if(getxCount() < get0Count()){

                winner = new Label("The White chips win!");
            }
            else{
                winner = new Label("It is a tie!");
            }
            gO.getChildren().addAll(gameOver, winner);
            gO.setAlignment(Pos.CENTER);
            gameOv.setCenter(gO);
            gP2.setCenter(gameOv);
            return gameOv;
        }//if for p1 player and p2 comp                                                                                                                                              

        clearPossible();
	possiblePlace(2);
	gP2.setCenter(upd);
        upd.setPrefWidth(480);
        upd.setPrefHeight(480);
        //gP2.setPrefSize(160, 160);                                                                                                                                             
        System.out.print("\n    1 2 3 4 5 6 7 8\n  ");
        for(int u = 0; u < 8; u++){
            System.out.print( u + 1);
            for(int m = 0; m < 8; m++){
                final int i = u;
                final int v = m;
                final int w = 1;
		if(board[i][v] == 0){
		    emptyChip[i+(8*v)] = new Circle(20,Color.GREEN);
		    upd.add(emptyChip[i+(8*v)], v, i);
		    
		    System.out.print(" .");
		}
		else if(board[i][v] == 1){
		    blackChips[i+(8*v)] = new Circle(20, Color.BLACK);
		    upd.add(blackChips[i+(8*v)], v, i);
		    System.out.print(" X");
		}
		else if(board[i][v] == 2){
		    whiteChips[i+(8*v)] = new Circle(20, Color.WHITE);
		    upd.add(whiteChips[i+(8*v)], v, i);
		    System.out.print(" 0");
		}
		else if(board[i][v] == 3){
		    possibleChip[i+(8*v)] = new Circle(20, Color.RED);
		    upd.add(possibleChip[i+(8*v)], v, i);
		    temp = i*v;
		    possibleChip[i+(8*v)].setOnMouseClicked(event -> {
			    System.out.println("Test!");
			    if(getAll() > 0){
				board[upd.getRowIndex(possibleChip[i+(8*v)])][upd.getColumnIndex(possibleChip[i+(8*v)])] = 2;
				flip((upd.getRowIndex(possibleChip[i+(8*v)])) , (upd.getColumnIndex(possibleChip[i+(8*v)])), 2);
				//possibleChip[i*v] = new Circle(20, Color.WHITE);
				clearPossible();
				printBoard(1);
			    }                                                                                                                                             
			    else{printBoard(1);                                                                                    
			    }                                                                                                                                             
                 
			});
		    System.out.print(" _");
		}
                        
	    }// everything else                                                                                                                                            
	    System.out.print("\n  ");
	}
        return gP2;
    }//printBoard                 
 
    /**
     * Gets total amount of team 2 tokens on board.
     *@return A counter equal to the total numebr of team two tokens
     */
    public int getAll(){
        int tot=0;
        for(int i = 0; i < 8; i++){
            for(int v = 0; v < 8; v++){
                if(board[i][v] == 3){
                    tot++;
                }
            }
        }
        //allSpace = board.getxCount() + board.get0Count();                                                                                                                          
        return tot;
    }
    /**                                                                                                                                                   
     *public void usePiece uses piece                                                                                                                              
     */
    public void usePiece(int row, int col, int team){
	if(board[row][col] == 3){
	   board[row][col] = team;
	}
	else{ System.out.print("Can't Make that Move");}
    }
    /*                                                                                                                                                    
     *public void getBoard 
     *@return Returns board to be used
     */
    public int[][] getBoard(){
	return board;
    }
    /**                                                                                                                                                   
     *public void clearPossible wipes the possible placements off the board                                                                                                                              
     */
    public void clearPossible(){
        for(int i = 0; i < 8; i++){
            for(int v = 0; v < 8; v++){
                if(board[i][v] == 3){
                    board[i][v] = 0;
                }
            }
        }
    }

    /**                                                                                                                                                   
     *public void flip checks the placed token and decides which chips to flip around it                                                                                                                              
     */
    public void flip(int row, int col, int team){
        int add;
        int otherTeam;
        int i = row;
        int v = col;
        if(team == 1){otherTeam = 2;}
        else{otherTeam = 1;}
        //for(int i = row; i < 8; i++){                                                                                                                                              
        //  for(int v = col; v < 8; v++){                                                                                                                                            
	add = 0;
	for(int r = 1; v+r < 8; r++){
	    if(board[i][v+r] == otherTeam){
		add++;

	    }
	    else if(board[i][v+r] == team){
		for(int b = add; b > 0; b--){
		    board[i][v+r-b] = team;
		}
	    }
	}
	//  }                                                                                                                                                            
	//  }//for-loop for the right side flips                                                                                                                         

	add = 0;
	for(int r = 1; v-r >=0; r++){
	    if(board[i][v-r] == otherTeam){
		add++;
	    }
	    else if(board[i][v-r] == team){
		for(int b = add; b>0; b--){
		    board[i][v-r+b]=team;
		}
	    }
	}//for-loop for the left side flips      
	add = 0;
	for(int r = 1; i+r < 8; r++){
	    if(board[i+r][v] == otherTeam){
		add++;
	    }
	    else if(board[i+r][v] == team){
		for(int b = add; b > 0; b--){
		    board[i+r-b][v] = team;
		}
	    }
	}                   
                    
	add = 0;
	for(int r = 1; i-r >=0; r++){
	    if(board[i-r][v] == otherTeam){
		add++;
	    }
	    else if(board[i-r][v] == team){
		for(int b = add; b>0; b--){
		    board[i-r+b][v]=team;
		}
	    }
	}
	add = 0;
	for(int r = 1; v-r >= 0 && i-r >= 0; r++){
	    if(board[i-r][v-r] == otherTeam){
		add++;
	    }
	    else if(board[i-r][v-r] == team){
		for(int b = add; b>0; b--){
		    board[i-r+b][v-r+b]=team;
		}
	    }
	}
	add = 0;
	for(int r = 1; v+r < 8 && i+r < 8; r++){
	    if(board[i+r][v+r] == otherTeam){
		add++;
	    }
	    else if(board[i+r][v+r] == team){
		for(int b = add; b>0; b--){
		    board[i+r-b][v+r-b]=team;
		}
	    }
	}
                    
	add = 0;
	for(int r = 1; v-r >= 0 && i+r < 8; r++){
	    if(board[i+r][v-r] == otherTeam){
		add++;
	    }
	    else if(board[i+r][v-r] == team){
		for(int b = add; b>0; b--){
		    board[i+r-b][v-r+b]=team;
		}
	    }
	}
                    
	add = 0;
	for(int r = 1; v+r < 8 && i-r >= 0; r++){
	    if(board[i-r][v+r] == otherTeam){
		add++;
	    }
	    else if(board[i-r][v+r] == team){
		for(int b = add; b>0; b--){
		    board[i-r+b][v+r-b]=team;
		}
	    }
	}
    }//flip                                  

    /**                                                                                                                                                 
     *public void possiblePlace takes a team param and decided where possible places are                                                                                                                              
     */
    public void possiblePlace(int team){
        int add;
        int otherTeam;
        if(team == 1){otherTeam = 2;}
        else{otherTeam = 1;}
        for(int i = 0; i < 8; i++){
            for(int v = 0; v < 8; v++){
                if(board[i][v] == team){
                    add = 0;
                    for(int r = 1; v+r < 8; r++){
                        if(board[i][v+r] == 0 && add > 0){
                            board[i][v+r] = 3;
                            add = 0;
                            break;
                        }
                        else if(board[i][v+r] == 0){
                            break;
                        }
                        else if(board[i][v+r] == team){
                            break;}
                        else if(board[i][v+r] == otherTeam){
                            add++;
                        }
                    }
                }
            }
        }//for-loop for right moving horizontal                                                                                                                                  
        for(int i = 7; i >= 0; i--){
            for(int v = 7; v >= 0; v--){
                if(board[i][v] == team){
                    add = 0;
                    for(int r = 1; v-r >= 0; r++){
                        if(board[i][v-r] == 0 && add > 0){
                            board[i][v-r] = 3;
                            add = 0;
                            break;
                        }
                        else if(board[i][v-r] == 0){
                            break;
			}
                        else if(board[i][v-r] == team){
                            break;}
                        else if(board[i][v-r] == otherTeam){
                            add++;
                        }
                    }
                }
            }
        }//for-loop for left moving horizontal                                                                                                                                   
        for(int i = 7; i >= 0; i--){
            for(int v = 7; v >= 0; v--){
                if(board[i][v] == team){
                    add = 0;
                    for(int r = 1; i-r >= 0; r++){
                        if(board[i-r][v] == 0 && add > 0){
                            board[i-r][v] = 3;
                            add = 0;
                            break;
                        }
                        else if(board[i-r][v] == 0){
                            break;
                        }
                        else if(board[i-r][v] == team){
                            break;}
			else if(board[i-r][v] == otherTeam){
                            add++;
                        }
                    }
                }
            }
        }//for-loop for upward vertical                                                                                                                                          
	for(int i = 0; i < 8; i++){
	    for(int v = 0; v < 8; v++){
		if(board[i][v] == team){
		    add = 0;
		    for(int r = 1; i+r < 8; r++){
			if(board[i+r][v] == 0 && add > 0){
			    board[i+r][v] = 3;
			    add = 0;
			    break;
			}
			else if(board[i+r][v] == 0){
			    break;
			}
			else if(board[i+r][v] == team){
			    break;}
			else if(board[i+r][v] == otherTeam){
			    add++;
			}
		    }
		}
	    }
	}//for-loop for downward vertical                                                                                                                                
	for(int i = 0; i < 8; i++){
	    for(int v = 0; v < 8; v++){
		if(board[i][v] == team){
		    add = 0;
		    for(int r = 1; v+r < 8 && i+r < 8; r++){
			if(board[i+r][v+r] == 0 && add > 0){
			    board[i+r][v+r] = 3;
			    break;
			}
			else if(board[i+r][v+r] == 0 || board[i+r][v+r] == 3 ){
			    break;
			}
			else if(board[i+r][v+r] == otherTeam){
			    add++;
			}
		    }
		}
	    }
	}//for-loop for diagnol downward right to left                                                                                                                   
	for(int i = 0; i < 8; i++){
	    for(int v = 0; v < 8; v++){
		if(board[i][v] == team){
		    add = 0;
		    for(int r = 1; i-r >= 0 && v+r < 8; r++){
			if(board[i-r][v+r] == 0 && add > 0){
			    board[i-r][v+r] = 3;
			    break;
			}
			else if(board[i-r][v+r] == 0 || board[i-r][v+r] == 3){
			    break;
			}
			else if(board[i-r][v+r] == otherTeam){
			    add++;
			}
		    }
		}
	    }
	}//for-loop for diagnol upward left to right                                                                                                                     
	for(int i = 0; i < 8; i++){
	    for(int v = 0; v < 8; v++){
		if(board[i][v] == team){
		    add = 0;
		    for(int r = 1; v-r >= 0 && i-r >= 0; r++){
			if(board[i-r][v-r] == 0 && add > 0){
			    board[i-r][v-r] = 3;
			    break;
			}
			else if(board[i-r][v-r] == 0|| board[i-r][v-r] == 3){
			    break;
			}
			else if(board[i-r][v-r] == otherTeam){   add++;
			}
		    }
		}
	    }
	}//for-loop for diagnol upward right to left                                                                                                                     
    }//possible                         

    public void getRandPlay(int randy, int team){
                                                                                                                                                
        int add = 0;
        int ranDig;
        ranDig =(int)(randy * Math.random());
        for(int i = 0; i < 8; i++){
            for(int v = 0; v < 8; v++){
                if(board[i][v] == 3){
                    if(add == ranDig){
                        board[i][v] = team;
                        flip(i ,v ,team);
		    }
                    add++;
                }
            }
        }
    }//getRandPlay                                         
    
    /**                                                                                                                                                    
     *public BorderPane printBoardRand2 is a printBoard method for a computer player
     *@return BorderPane 
     */
    public BorderPane printBoardRand2(int team){
	backToHome.setOnAction(e -> {
                gO.getChildren().clear();
                gO.getChildren().addAll(tetris, reversi);
                gO.setAlignment(Pos.CENTER);
                gameOv.setCenter(gO);
                gP2.setCenter(gameOv);
            });
	possiblePlace(1);
	possiblePlace(2);
	if(win() == false){
            Label gameOver = new Label("Game Over");
            if(getxCount() > get0Count()){
                winner = new Label("The black chips win!");
            }
            else if(getxCount() < get0Count()){

                winner = new Label("The White chips win!");
            }
            else{
                winner = new Label("It is a tie!");
            }
            gO.getChildren().addAll(gameOver, winner);
            gO.setAlignment(Pos.CENTER);
            gameOv.setCenter(gO);
	    gP2.setCenter(gameOv);
            return gameOv;
        }//if for p1 player and p2 comp             
	clearPossible();

	possiblePlace(2);
	gP2.setCenter(upd);
	upd.setPrefWidth(480);
	upd.setPrefHeight(480);
	//gP2.setPrefSize(160, 160);                                                                                                                                            
	if(win() == false){
	    Label gameOver = new Label("Game Over");
	    if(getxCount() > get0Count()){
		winner = new Label("The black chips win!");
	    }
	    else if(getxCount() < get0Count()){                                                                                                                            

		winner = new Label("The White chips win!");
	    }
	    else{
		winner = new Label("It is a tie!");
	    }
	    gO.getChildren().addAll(gameOver, winner);
	    gO.setAlignment(Pos.CENTER);
	    gameOv.setCenter(gO);
	    return gameOv;
	}//if for p1 player and p2 comp     


	System.out.print("\n    1 2 3 4 5 6 7 8\n  ");
	for(int u = 0; u < 8; u++){
	    System.out.print( u + 1);
	    for(int m = 0; m < 8; m++){
		final int i = u;
		final int v = m;
		final int w = 1;
		if(board[i][v] == 0){
		    emptyChip[i+(v*8)] = new Circle(20,Color.GREEN);
		    upd.add(emptyChip[i+(v*8)], v, i);
		    System.out.print(" .");
		}
		else if(board[i][v] == 1){
		    blackChips[i+(8*v)] = new Circle(20, Color.BLACK);
		    upd.add(blackChips[i+(8*v)], v, i);
		    System.out.print(" X");
		}
		else if(board[i][v] == 2){
		    whiteChips[i+(8*v)] = new Circle(20, Color.WHITE);
		    upd.add(whiteChips[i+(8*v)], v, i);
		    System.out.print(" 0");
		}
		else if(board[i][v] == 3){
		    possibleChip[i+(8*v)] = new Circle(20, Color.RED);
		    upd.add(possibleChip[i+(8*v)], v, i);
		    temp = i*v;
		    System.out.print(" _");	
		}
	    }
	    System.out.print("\n");
	}
	if (getAll() > 0){			    
	    getRandPlay(getAll(), 2);
	    clearPossible();
	    //gP2.setCenter(upd);          
	    
		printBoard(1);
		return gP2;  
	}else{
	    printBoard(1);
	}
	    return gP2;
    }//printBoardRand2                           
    
    /**                                                                                                                                                    
     *public boolean win determines the winner of the game
     *@return boolean
     */
    public boolean win(){
        int counter = 0;
        int posCounter = 0;
        for(int i = 0; i < 8; i++){
            for(int v = 0; v < 8; v++){
                if(board[i][v] == 1 || board[i][v] == 2){
                    counter++;
                }
                else if(board[i][v] == 3){
                    posCounter++;
                }
            }
        }
        if(counter == 64){
            return false;
	}
        else if(posCounter == 0){
            return false;
	}

	return true;

    }//win                                                                                                                                                 
    /**                                                                                                                                                    
     *public int getxCount
     *@return counter
     */ 
    public int getxCount(){
	int counter = 0;
	for(int i = 0; i < 8; i++){
	    for (int j = 0; j < 8; j++){
		if( board[i][j] == 1){
		    counter++;
	    
		}
	    }
	}
	return counter;
    }
    /**                                                                                                                                                   
                                                                                                                                                        
     *public int getOCount                                                                                                                               
     *@return counter                                                                                                                                     
     */
    public int get0Count(){
        int counter = 0;
        for(int i = 0; i < 8; i++){
            for (int j = 0; j < 8; j++){
                if( board[i][j] == 2){
                    counter++;

                }
            }
        }
        return counter;
    }
}//Board