//package cs1302-reversi.cs1302.p2;
package cs1302.arcade;;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Dialog;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import java.util.Scanner;
import javafx.application.Application;    
import javafx.scene.layout.Pane;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.shape.*;
import javafx.scene.paint.Color;
import javafx.geometry.*;

/**
 * @author Grant Godbee
 * Runs Reversi Application using board.java
 */
public class App extends Application 
{
    String p1isComp;
    String p2isComp;
    static int gameVar = 0;
    BorderPane gP;
    BorderPane borderpane;
    HBox hbox;
    public App(){
	borderpane = new  BorderPane();
	gP = new BorderPane();
	hbox = new HBox();
	borderpane.setCenter(gP);
	run();
    }
    public Pane getRoot(){
        return borderpane;
    }
    public BorderPane updateGrid(BorderPane update){
	gP = update;
	return gP;
    }
    public void run()
    {
	Button pA = new Button("Play Computer");
	pA.setOnAction(e -> {
		gameVar = 1;
		startGame();
	    });
	Button pA2 = new Button("Play Friends");
	pA2.setOnAction(e -> {
		gameVar = 2;
		startGame();
	    });
	
	
	Label rule = new Label("Red tokens mark possible placements!");
	HBox rules = new HBox();
	Circle examp = new Circle(5, Color.RED);
	rules.getChildren().addAll(examp , rule, pA, pA2);
	rules.setSpacing(7.0);
	rules.setAlignment(Pos.CENTER);
	borderpane.setBottom(rules);
	final Menu topMenu = new Menu("File");
	final Menu helpMenu = new Menu("Help");
	MenuBar menuBar = new MenuBar();
	menuBar.getMenus().addAll(topMenu, helpMenu);
	MenuItem exitItem = new MenuItem("Exit");
	MenuItem aboutItem = new MenuItem("About Grant Godbee");
        
	aboutItem.setOnAction(e->{
		Alert alert = new Alert(AlertType.WARNING);
		alert.setTitle("About Creators");
		alert.setHeaderText("Grant Godbee email:");
		alert.setContentText("Version 1.0.0");
		
		alert.showAndWait();
	    });
	exitItem.setOnAction(e->{                Platform.exit();
		System.exit(0);
	    });
	
	topMenu.getItems().add(exitItem);
	helpMenu.getItems().add(aboutItem);
	
     	
	Button yes1 = new Button("Play a Computer?");
	Button no1 = new Button("Play a Friend?");
	hbox.setSpacing(30.0);
	hbox.getChildren().addAll( yes1, no1);
	borderpane.setCenter(hbox);
	borderpane.setTop(menuBar);
	hbox.setAlignment(Pos.CENTER);
	yes1.setOnAction(e -> {
		gameVar = 1;
		startGame();
	    });
	no1.setOnAction(e -> {
		gameVar = 2;
		startGame();
            });
    }
    public static int gameV(){
	return gameVar;
    }
    public void startGame(){
    	if(gameVar == 2){
    	    ReversiBoard board = new ReversiBoard();
    	    HumanPlayer player1 = new HumanPlayer();
    	    RandomComputerPlayer player2 = new RandomComputerPlayer();
    	    board.Board();	    
	    updateGrid(board.printBoard(1));
	    borderpane.setCenter(gP);
	    borderpane.setAlignment(gP, Pos.CENTER);
	    
	    
	    
	    
	}//if gameVar 2
	else if(gameVar == 1){
	    ReversiBoard board = new ReversiBoard();
            HumanPlayer player1 = new HumanPlayer();
            RandomComputerPlayer player2 = new RandomComputerPlayer();
            board.Board();
            updateGrid(board.printBoard(1));
            borderpane.setCenter(gP);
	}
	
    }//startGame
    
    public void start(Stage primarySTage) throws Exception {
	
    }   
    
}//start
