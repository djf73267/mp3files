To run the program
1. if you need to compile the class first then javac MineSweeper.java
2. to run java MineSweeper
