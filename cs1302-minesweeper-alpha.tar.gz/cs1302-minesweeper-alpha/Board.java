import java.util.Random;
import java.util.Scanner;

public class Board {
    private int[][] mines; //2d integer array 
    
    private String[][] boardgame; //2d string array
    
    private int Row, Column;
    
    private String Splitter; //will split the letters from the numbers
    
    private String numberY; //will become the y value of the numbers 
    
    Random random = new Random();
    
    Scanner input = new Scanner(System.in);
    
	private String numberX;
    
    public Board (){ //constructor
    	
        mines = new int[11][11]; 
        
        boardgame = new String[11][11];
        
        startMines();
        
        randomMines();
        
        numberCheck();
        
        startBoard();
        
    }
    public int getPlacement(int Row, int Column){
        return mines[Row][Column];
    }
    
    public boolean setPlacement(){
        
        do{
        	System.out.print("Numbers here: ");
        	
        	Splitter = input.nextLine(); //input the string of guess reveal or mark
        	
           if (Splitter.charAt(0) == 'r' || Splitter.charAt(0) == 'R'){
        	   
            numberY =""+ Splitter.charAt(2);
            
            Row= Integer.parseInt(numberY);
            
            numberX= ""+Splitter.charAt(4);
            
            Column = Integer.parseInt(numberX);
           }
         if (Splitter.charAt(0) == 'm' ||(Splitter.charAt(0) == 'M')){
        	   numberY =""+ Splitter.charAt(2);
               
               Row= Integer.parseInt(numberY);
               
               numberX= ""+Splitter.charAt(4);
               
               Column = Integer.parseInt(numberX);
                       	
                           boardgame[Row][Column]="|   F";
                           show(); // will show the board updated after the command
                       }
         if (Splitter.charAt(0) == 'g' ||(Splitter.charAt(0) == 'G')){
      	   numberY =""+ Splitter.charAt(2);
             
             Row= Integer.parseInt(numberY);
             
             numberX= ""+Splitter.charAt(4);
             
             Column = Integer.parseInt(numberX);
                     	
                         boardgame[Row][Column]="|   ?";
                         show();
                     }
         if(Splitter.equalsIgnoreCase("quit")||Splitter.equalsIgnoreCase("q")){ //will quit out the program 
      	   System.exit(0);
         }
         if (Splitter.equalsIgnoreCase("h")||Splitter.equalsIgnoreCase("help")){ // will give the command options
         System.out.println("- Reveal: r/reveal row col \n-   Mark: m/mark   row col \n-  Guess: g/guess  row col \n-   Help: h/help \n-   Quit: q/quit");} 
                
            if( (boardgame[Row][Column] != "|    " && boardgame[Row][Column]!="|   ?" && boardgame[Row][Column]!="|   F")) // will show a messgage about preventing retyping
            	
                System.out.println("Field already shown");
            
           
            
        }while((Row < 0 || Row > 10 || Column < 0 || Column > 10) || (boardgame[Row][Column] != "|    ")||(boardgame[Row][Column]!="|   ?") || (boardgame[Row][Column]!="|   F") );
        
        if(getPlacement(Row, Column)== -1)
        	
            return true;
        else
            return false;
        
}
    public void areaOpen(){
    	
    	int i = 0;
    	
    	int j =0;
    	
        while( i<2 ){
        	
            while(j<2 ){
            	
                if( (mines[Row+i][Column+j] != -1) && Row != 10 && Column != 10) {
                	
                    boardgame[Row+i][Column+j]="|   "+Character.forDigit(mines[Row+i][Column+j], 11); //will list the location where you input the row and column
                }
                j++;
            }
            i++;
        }
    }
    
    
    
    
    
    public void numberCheck(){
    	int Row = 1;
        while(Row < 10 ) {
        	
            for(int column=1 ; column < 10 ; column++){
           
                    for(int i=-1 ; i<=1 ; i++) {
                    	
                        for(int j=-1 ; j<=1 ; j++) {
                        	
                            if(mines[Row][column] != -1) {
                            	
                                if(mines[Row+i][column+j] == -1) {
                                	
                                    mines[Row][column]++;
                           }   
                        }   
                    }
                }
            }
            Row++;
        }  
        Row = 1;
    }
    
    public void showMines(){
    	
    	int i = 0;
    	
        while(i < 10) {
        	
        
            for(int j=1 ; j < 10 ; j++) {
            	
                if(mines[i][j] == -1) {
                	
                    boardgame[i][j]="|   *";
                }
            }
            i++;
        }
        show();
    }
    
    public void startBoard(){
    	
    	int i = 0;
    	
        while(i<mines.length) {
        	
            for(int j=0 ; j<mines.length ; j++) {
            	
                boardgame[i][j]= "|    ";
            }
            i++;
        }
    }
    
    public void startMines(){
    	
    	int i = 0;
    	
        while(i<mines.length ) {
        	
            for(int j=0 ; j<mines.length ; j++) {
            	
                mines[i][j]=0;
            }
            i++;
        }
    }
    
    public void randomMines(){ //randomizes mines
    	
        boolean lottery;
        
        int Row, Column;
        
        int i = 0;
        
        while(i<11){
            
            do{
                Row = random.nextInt(9) + 1;
                
                Column = random.nextInt(9) + 1;
                
                if(mines[Row][Column] == -1)
                	
                    lottery=true;
                
                else
                	
                    lottery = false;
                
            }while(lottery);
            
            mines[Row][Column] = -1;
            
            i++;
        }
    }
    public void show(){ //shows board
    	
        int Row = 0;
        
        while( Row < 10 ){
        	
            System.out.print("   "+Row + "   ");
            
            for(int Column = 0 ; Column < 10 ; Column++){
            	
                    System.out.print("     "+ boardgame[Row][Column]);
            }
                
            System.out.println();
            
            Row++;
        }
            
        System.out.println("\n                0         1         2         3         4           5         6        7        8        9  \n");
      
        
    }
    
    public boolean win(){
    	
        int count=0;
        
      int  Row = 0;
      
      int column = 0;
      
        while(Row < 10 ){
        	
            while( column < 10){
            	
                if(boardgame[Row][column]=="|    "){
                	
                    count++;
                }
                
                column++;
                
            }
            
            Row++;
            
        }
        
        if(count == 11){
        	
            return true;
        }
        
        else{
            return false;  
        }
    }
}