public class Game {
    private Board board;
    boolean gameOver = false;
    boolean win = false;
    int turn=0;
    
    public Game(){
        board = new Board();
        Play(board); //sets board
    }
    
    public void Play(Board board){
        do{
            
            System.out.println("Rounds Completed:  "+turn); //round counter 
            board.show();
            gameOver = board.setPlacement();
            
            if(!gameOver){
                board.areaOpen();
                gameOver = board.win();
            }
        turn++;    
        }while(!gameOver);
        
        if(board.win()){
            System.out.println(""); //couldnt use the emotes without issue
            board.showMines();
        } else {
            System.out.println("Oh no... You revealed a mine!");
            board.showMines();
        }
    }
}