1.
Unit testing is testing the smallest parts of an application indvidually

Integration testing is the testing of indvidual applications by combining then and testing 

System testing is the entire application

JUnit 5 is the combination of JUnit Platform + JUnit Jupiter + JUnit Vintage

JUnit Platform is the base of launching testing frameworks and provides a console launcher to launch the platform from 

the command line.

JUnit Jupiter is a another combination but this time its a combination of the new programming model and extension model 

for writing tests and extensions in JUnit 5

JUnit Vintage provides a TestEngine for running for the previous JUnits 3 and 4
4)
1. @BeforeEach makes sure that the method is exceuted before each test
2. @After makes sure that the method is exceuted after each test
3. @test is the method that gets run during the test
4. Assertions.assertEquals asserts two objects are equal
5. Assertions.assertThrows which allows you to test multiple exceptions within the same test
