package cs1302.hw5;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class BasicSalaryCalculator {
  private double basicSalary;
  private BasicSalaryCalculator basicSalaryCalculator;

  public double getBasicSalary() {
    return basicSalary;
  }
  @BeforeEach
  public void init() {
  
  
  
  
  
    basicSalaryCalculator = new BasicSalaryCalculator ();
  }
  @AfterEach
  public void tearDown() {
  
  basicSalaryCalculator = null;
  }
@Test
void testBasicSalaryWithValidSalary() {
double basicSalary = 4000;
basicSalaryCalculator.setBasicSalary(basicSalary);
double expectedSocialInsurance = basicSalary * 0.25;
assertEquals(expectedSocialInsurance, basicSalaryCalculator.getSocialInsurance());
double expectedAddionalBonus = basicSalary * 0.1;assertEquals(expectedAddionalBonus, basicSalaryCalculator.getAdditionalBonus());
double expectedGross = basicSalary + expectedSocialInsurance + expectedAddionalBonus;
assertEquals(expectedGross, basicSalaryCalculator.getGrossSalary());

}
@Test
void testBasicSalaryWithInValidSalary() {
double basicSalary = -100;
assertThrows(IllegalArgumentException.class, () -> {basicSalaryCalculator.setBasicSalary(basicSalary);});

}
  public void setBasicSalary(double basicSalary) {
    if (basicSalary < 0) {
      throw new IllegalArgumentException("Negative salary is invalid.");
    }
    this.basicSalary = basicSalary;
  }

  public double getGrossSalary() {
    return this.basicSalary + getSocialInsurance() + getAdditionalBonus();
  }

  public double getSocialInsurance() {
    return this.basicSalary * 25 / 100;
  }

  public double getAdditionalBonus() {
    return this.basicSalary / 10;
  }
}
