to compile the user must you javac reversi.java and then to run the user must use java Reversi
