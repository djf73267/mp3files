
import java.util.Arrays;

import java.util.Scanner;

public class Reversi {

	

	private char board[][];

	private char playerX = 'X', playerO = 'O';

	private int playerXScore, playerOScore;

	public Reversi()

	{
		board = new char[9][9]; //created a nine by nine multidimensional array becuase theres is arraysoutofboundsexceptions when dealing with the max of the array

		Board(); //calls the method board to create the board when the game is called in main.

	}

	private void Board() // method Board creates a board with a center at 4 which but since this is a even multidimensional array the 4 player tiles must be adjacent to each other in a square.

	{
		int i = 0;
		
		while(i < 8)
			
		{
			for (int j = 0; j < 8; j++)
			{
				board[i][j] = '.'; 
			}
			i++;
		}
		// the center of the board

		int center = 8 / 2;

		board[center - 1][center] = playerO;

		board[center][center - 1] = playerO;

		board[center - 1][center - 1] = playerX;

		board[center][center] = playerX;
				

		playerXScore = 2;

		playerOScore = 2;

	}

	public boolean cell(char player, int row, int col)//realized cell can be associated to player if you make a parameter that lets the player be generic and have specific conditions for each player later

	{

		// each pair show different directions of x,y changing

		
		int cellCheck[][] = new int [8][2]; //(0,1), (1,1), (1,0), (1,-1), (0,-1),(-1,-1),(-1,0),(-1,1) are the orders pairs in a multidimensional array and the rows and columns are for each separate coordinate to determine what tiles are near it
		cellCheck [0][0] = 0; 
		cellCheck [1][0] = 1;
		cellCheck [2][0] = 1;
		cellCheck [3][0] = 1;
		cellCheck [4][0] = 0;
		cellCheck [5][0] = -1;
		cellCheck [6][0] = -1;
		cellCheck [7][0] = -1;
		cellCheck [0][1] = 1;
		cellCheck [1][1] = 1;
		cellCheck [2][1] = 0;
		cellCheck [3][1] = -1;
		cellCheck [4][1] = -1;
		cellCheck [5][1] = -1;
		cellCheck [6][1] = 0;
		cellCheck [7][1] = 1;

	
		if (board[row ][col ] != '.') {// if the slot is not empty it will return false if slot is empty then game ends

			return false;
			}

		boolean opponent = false;

		int myRow;
		
		int myColumn;
		
		int i = 0;
		
		while (i < 8) 
		{

			myRow = row + cellCheck[i][1] ; // myRow is the loop check that will go through each possible tile near the row tile 

			myColumn = col +  cellCheck[i][0] ; // same case here

			opponent = false;

			while (true)

			{

				if ((myRow < 0 || myRow >= 9 ||  myColumn >= 9 || myColumn < 0 )) // out of bounds if its less than 0 or equal to 9 which is the array size 

					break;

				if (board[myRow][myColumn] == '.') // if the board finds a empty tile then skip 

					break;

				else if (board[myRow][myColumn] == player) //player tile wil be split into two possible outcomes opponent tile or my tile 

				{

					if (opponent == true) // opponent tile

						return true;

					else

						break; // else no opponent found
				}

				else // found opponent

				{

					opponent = true;

				}

				myRow = myRow + cellCheck[i][1];

				myColumn = myColumn + cellCheck[i][0];

			}
			i++;

		}

		return false;

	}

	
	private int flip(char player, boolean flip, int row, int col)//similar method to cell but is an integer of flips rather a boolean method

	{
		


		int flips = 0;
		int i = 0;
		
		int directions[][] = new int [8][2]; //(0,1), (1,1), (1,0), (1,-1), (0,-1),(-1,-1),(-1,0),(-1,1) are the orders pairs in a multidimensional array and the rows and columns are for each separate coordinate to flip the tiles near it
		directions [0][0] = 0; 
		directions [1][0] =1;
		directions [2][0] =1;
		directions [3][0] =1;
		directions [4][0] =0;
		directions [5][0] =-1;
		directions [6][0] =-1;
		directions [7][0] =-1;
		directions [0][1] =1;
		directions [1][1] =1;
		directions [2][1] =0;
		directions [3][1] =-1;
		directions [4][1] =-1;
		directions [5][1] =-1;
		directions [6][1] =0;
		directions [7][1] =1;
		int myRow, myColumn;

		boolean opponent;

		while (i < 8)

		{

			myRow = row + directions[i][1];

			myColumn = col + directions[i][0];

			opponent = false;

			while (opponent = true)

			{

				if ((myRow < 0 || myRow >= 9 ||  myColumn >= 9 || myColumn < 0 )) // out of board

					break;

				if (board[myRow][myColumn] == '.') // a blank

					break;

				else if (board[myRow][myColumn] == player) // reached the player's tile

				{

					if (opponent = true ) // if an opponent tile was found in between

					{

						
						int opponentRow, opponentColumn;

						opponentRow = row + directions[i][1];

						opponentColumn = col + directions[i][0];

						// count all the tiles that were seen, and if need to be flipped, flip them

						while (opponentRow != myRow|| opponentColumn != myColumn)

						{

							flips++;

							if (flip)

								board[opponentRow][opponentColumn] = player;

							opponentRow = opponentRow + directions[i][1];

							opponentColumn = opponentColumn + directions[i][0];

						}

					}

					break;

				}

				else

				{

					opponent = true;

				}

				myRow = myRow + directions[i][1];

				myColumn = myColumn + directions[i][0];

			}
			i++;
		}

		return flips;

	}

	//computer
	public int[] getMove(char player)

	{

		int count;
		int maxCount = 0;

		int row = -1, column = -1 ;
		int i= 0;
		
		while (i < 8)

		{

			for (int j = 0; j < 8; j++)

			{
				
				if (cell(player, i, j)==true)

				{

					count = flip( player, false, i, j);

					if (!(count <= maxCount))

					{

						row = i;

						column = j;

						maxCount = count;

					}

				}

			}
			i++;
		}

		int move[] = {row , column};

		
		return move;

	}

	private void grid()

	{

		int i = 0;
		
		System.out.print("  1   2   3   4   5   6   7   8");
		
		while (i < 8)

		{
			int k = i + 1;
			System.out.print("\n" + k + "");

			for (int j = 0; j < 8; j++)

			{

				System.out.print(" " + board[i][j] + "  ");

			}

			i++;
		}

		System.out.print("\n");

	}

	private boolean gameOver(char currentPlayer)

	{

		int move[] = getMove(currentPlayer);

		if (!(move[0] == -1 || move[1] == -1))

			return false;

		else

			return true;

	}

	public boolean makeMove(int row, int col, char player)

	{

		int flips;

		if (cell(player, row, col) == true)

		{

			flips = flip(player, true, row, col); // flip tiles

			board[row][col] = player;

			if (player == playerO)

			{
playerOScore = playerOScore + flips + 1; //plus one beacuse of the extra point including the rest of the flips 
				playerXScore =  playerXScore - flips;// subtract from original with flips 
			// plus score
				
				

			}

			else

			{

				playerXScore =  playerXScore + flips + 1;// similar but with X's
				playerOScore = playerOScore - flips;// negative score



			}

			return true;

		}

		else

			return false;

	}
 
	public char getWinner()// returns winner based on the score they recieved at end game

	{
	
		if (playerXScore == playerOScore)

			return ' ';
		

		else if (playerXScore < playerOScore)

			return playerO;

		else

			return playerX;

	}

	public int getPlayerScore(char player) //returns score

	{

		if (playerX == player)

			return playerXScore;

		else

			return playerOScore;

	}

	public void startHumanvComputer()

	{

		Scanner keyboard = new Scanner(System.in);

		char player = playerX;

		int r, c;

		grid();

		while (!gameOver(player))

		{

			if (player == playerX)

			{

				System.out.print("\nMove piece (" + player + ") : ");
				String a = keyboard.nextLine();
				
			
			if(a.equalsIgnoreCase("quit")) {
				System.exit(0);
			}
				String aSub = a.substring(0,1);
				
				String aSub2 = a.substring(2);
				
				c = Integer.parseInt(aSub) - 1  ;
				
				r = Integer.parseInt(aSub2) - 1 ;
				
				

			}

			else

			{

				int move[] = getMove(player);

				r = move[0];

				c = move[1];

			}

			if (makeMove(r, c, player))

			{

				System.out.print("\n" + player + " moved (" + (c  + 1) + ", " + (r + 1) +")");

				if (player == playerX)

				{

					System.out.print(" Score: " + playerXScore + "\n");

					player = playerX;

				}

				else

				{

					System.out.print(" Score: " + playerOScore + "\n");

					player = playerO;

				}

			grid();

			}

			else

			{

				System.out.println("Not a valid move please try again");

			}

		}

		

	}
	
	public void startHumanvHuman()

	{

		Scanner keyboard = new Scanner(System.in);

		char player = playerX;

		int r, c;

		grid();

		while (!gameOver(player))

		{

			if (player == playerX)

			{

				System.out.print("\nMove piece (" + player + ") : ");
				String a = keyboard.nextLine();
				
			
			if(a.equalsIgnoreCase("quit")) {
				System.exit(0);
			}
				String inputSub = a.substring(0,1);
				
				String inputSub2 = a.substring(2);
				
				c = Integer.parseInt(aSub) - 1  ;
				
				r = Integer.parseInt(aSub2) - 1 ;
				
				

			}

			else

			{


				System.out.print("\nMove piece (" + player + ") : ");
				String a = keyboard.nextLine();
				
			
			if(a.equalsIgnoreCase("quit")) {
				System.exit(0);
			}
				String aSub = a.substring(0,1);
				
				String aSub2 = a.substring(2);
				
				c = Integer.parseInt(aSub) - 1  ;
				
				r = Integer.parseInt(aSub2) - 1 ;
				
				


			}
			if (makeMove(r, c, player))

			{

				System.out.print("\nSuccess: " + player + " move at (" + (c  + 1) + ", " + (r + 1) +")");

				if (player == playerX)

				{

					System.out.print(" Score: " + playerXScore + "\n");

					player = playerX;

				}

				else

				{

					System.out.print(" Score: " + playerOScore + "\n");

					player = playerO;

				}

				grid();

			}

			else

			{

				System.out.println("Not a valid move please try again");

			}

		}

		

	}
	public void startComputervComputer()

	{

		Scanner keyboard = new Scanner(System.in);

		char player = playerX;

		int r, c;

		grid();

		while (!gameOver(player))

		{

			if (player == playerX)

			{

				int move[] = getMove(player);

				r = move[0];

				c = move[1];
				

			}

			else

			{

				int move[] = getMove(player);

				r = move[0];

				c = move[1];

			}

			if (makeMove(r, c, player))

			{

				System.out.print("\nSuccess: " + player + " move at (" + (c  + 1) + ", " + (r + 1) +")");

				if (player == playerX)

				{

					System.out.print(" Score: " + playerXScore + "\n");

					player = playerO;

				}

				else

				{

					System.out.print(" Score: " + playerOScore + "\n");

					player = playerX;

				}

				grid();

			}

			else

			{

				System.out.println("Not a valid move please try again");

			}

		}	

	}
	public void Scores()

	{

		char winner = getWinner();

		System.out.println("Player1 : " + playerX + " Score: " + playerXScore);

		System.out.println("Player2 : " + playerO + " Score: " + playerOScore);

		if (winner == ' ')

			System.out.println("Its a Tie! ");

		else

		{

			if (playerO == winner)

				System.out.println("Player O wins!");

			else

				System.out.println("Player X wins!");

		}

	}

	public static void main(String[] args) {
		
		Scanner keyboard = new Scanner(System.in);
		Reversi reversiBoard = new Reversi();
		System.out.println("Human v Human: 1 Human v Computer: 2 Computer v Computer: 3");
		String choice = keyboard.nextLine();
		
		if (choice.equals("1")) {
			reversiBoard.startHumanvHuman();

			reversiBoard.Scores();
		}
		else if (choice.equals("2")) {
			reversiBoard.startHumanvComputer();
			
			reversiBoard.Scores();
		}
		else if (choice.equals("3")) {
			reversiBoard.startComputervComputer();
			
			reversiBoard.Scores();
		}
		else {
			
		}
		

	}

}